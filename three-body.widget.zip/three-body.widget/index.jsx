import { run } from 'uebersicht';
export const command = undefined;
export const refreshFrequency = false;
export const className = `
  top: 0; left: 0; right: 0; bottom: 0;
  width: 100%; height: 100%;
  margin: 0; padding: 0; overflow: hidden;
`;
let htmlContent = '';
export const init = (dispatch) => {
  const dir = '/Users/html/Library/Application Support/Übersicht/widgets/three-body.widget';
  run(`cat "${dir}/lib/index.html"`).then((output) => dispatch({ type: 'HTML_LOADED', html: output }));
};
export const updateState = (event, prev) => event.type === 'HTML_LOADED' ? { loaded: true, html: event.html } : prev;
export const initialState = { loaded: false, html: '' };
export const render = ({ loaded, html }) => loaded
  ? <iframe srcDoc={html} style={{ width: '100%', height: '100%', border: 'none', pointerEvents: 'all' }} />
  : <div style={{ color: '#fff' }}>Loading...</div>;
